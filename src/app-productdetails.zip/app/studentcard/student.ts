export class Student{
    id:number=0;
    studentName:string="";
    studentAge:number=0;
    studentPhone:number=0;
    studentAddress:any[]=[];
    studentBranch:number=0;
}